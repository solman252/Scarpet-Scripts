scoreboard objectives add setup_complete dummy
execute unless score setup_complete setup_complete matches 1 run function auto_gamerules:setup