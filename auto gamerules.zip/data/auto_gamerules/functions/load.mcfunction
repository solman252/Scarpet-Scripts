scoreboard objectives add setup_complete dummy
execute if score setup_complete setup_complete matches 0 run function auto_gamerules:setup