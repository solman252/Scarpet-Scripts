gamerule doImmediateRespawn true
gamerule playersSleepingPercentage 1
gamerule spawnRadius 0
gamerule blockExplosionDropDecay false
gamerule mobExplosionDropDecay false
gamerule doVinesSpread false
gamerule lavaSourceConversion true

carpet setDefault commandScript true
carpet setDefault commandScriptACE 0
carpet setDefault ctrlQCraftingFix true
carpet setDefault fastRedstoneDust true
carpet setDefault huskSpawningInTemples true
carpet setDefault lagFreeSpawning true
carpet setDefault lightningKillsDropsFix true
carpet setDefault liquidDamageDisabled true
carpet setDefault mergeTNT true
carpet setDefault missingTools true
carpet setDefault optimizedTNT true
carpet setDefault renewableBlackstone true
carpet setDefault renewableCoral true
carpet setDefault renewableDeepslate true
carpet setDefault renewableSponges true
carpet setDefault shulkerSpawningInEndCities true
carpet setDefault stackableShulkerBoxes 16
carpet setDefault xpFromExplosions true
carpet setDefault xpNoCooldown true

script download survival/carried_totem.sc
script download survival/combine_xp_orbs.sc
script download survival/drop_heads.sc
script download survival/easier_renewable_sponge.sc
script download survival/enchanting_table_bottling.sc
script download survival/instamine_deepslate.sc
script download survival/nopickup.sc
script download survival/revive_coral.sc
script download survival/rope_ladders.sc
script download survival/silk_budding_amethyst.sc
script download survival/silk_spawners.sc
script download survival/vines_instant_mine.sc

script load survival/combine_xp_orbs.sc
script load survival/carried_totem.sc
script load survival/drop_heads.sc
script load survival/easier_renewable_sponge.sc
script load survival/enchanting_table_bottling.sc
script load survival/instamine_deepslate.sc
script load survival/nopickup.sc
script load survival/revive_coral.sc
script load survival/rope_ladders.sc
script load survival/silk_budding_amethyst.sc
script load survival/silk_spawners.sc
script load survival/vines_instant_mine.sc

script load citify.sc
script load dontmine.sc
script load easy_move_beacon.sc
script load fire_aspect_smelting.sc
script load home.sc
script load instamine_stone.sc

schedule function auto_gamerules:done 5s