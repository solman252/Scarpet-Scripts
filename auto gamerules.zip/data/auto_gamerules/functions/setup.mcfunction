gamerule doImmediateRespawn true
gamerule playersSleepingPercentage 1
gamerule spawnRadius 0
gamerule blockExplosionDropDecay false
gamerule mobExplosionDropDecay false
gamerule doVinesSpread false
gamerule lavaSourceConversion true

carpet setDefault commandScript true
carpet setDefault commandScriptACE 0
carpet setDefault ctrlQCraftingFix true
carpet setDefault fastRedstoneDust true
carpet setDefault huskSpawningInTemples true
carpet setDefault lagFreeSpawning true
carpet setDefault lightningKillsDropsFix true
carpet setDefault liquidDamageDisabled true
carpet setDefault mergeTNT true
carpet setDefault missingTools true
carpet setDefault optimizedTNT true
carpet setDefault renewableBlackstone true
carpet setDefault renewableCoral true
carpet setDefault renewableDeepslate true
carpet setDefault renewableSponges true
carpet setDefault shulkerSpawningInEndCities true
carpet setDefault stackableShulkerBoxes 16
carpet setDefault xpFromExplosions true
carpet setDefault xpNoCooldown true

script download survival/carried_totem.sc
script download survival/combine_xp_orbs.sc
script download survival/drop_heads.sc
script download survival/easier_renewable_sponge.sc
script download survival/enchanting_table_bottling.sc
script download survival/instamine_deepslate.sc
script download survival/nopickup.sc
script download survival/revive_coral.sc
script download survival/rope_ladders.sc
script download survival/silk_budding_amethyst.sc
script download survival/silk_spawners.sc
script download survival/vines_instant_mine.sc

script load survival/combine_xp_orbs
script load survival/carried_totem
script load survival/drop_heads
script load survival/easier_renewable_sponge
script load survival/enchanting_table_bottling
script load survival/instamine_deepslate
script load survival/nopickup
script load survival/revive_coral
script load survival/rope_ladders
script load survival/silk_budding_amethyst
script load survival/silk_spawners
script load survival/vines_instant_mine

script load citify
script load dontmine
script load easy_move_beacon
script load fire_aspect_smelting
script load home
script load instamine_stone

schedule function auto_gamerules:done 5s